const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

//For HTML file
app.get('/', (req, res) => {
    fs.readFile(path.join(__dirname, 'index.html'), 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Error loading the page');
            return;
        }
        res.send(data);
    });
});

// For CSS file
app.get('/styles.css', (req, res) => {
    fs.readFile(path.join(__dirname, 'styles.css'), 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Error loading CSS');
            return;
        }
        res.setHeader('Content-Type', 'text/css');
        res.send(data);
    });
});

io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('chat message', (msg) => {
        io.emit('chat message', msg);
    });

    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});

server.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
