const express = require('express');
const mongoose = require('mongoose');
const Post = require('./models/Post');
const app = express();
const dotenv = require('dotenv');

dotenv.config();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set up EJS for templating
app.set('view engine', 'ejs');

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected...'))
.catch(err => console.log(err));

// Routes
app.get('/', async (req, res) => {
    try {
        const posts = await Post.find().sort({ createdAt: -1 });
        res.render('index', { posts });
    } catch (error) {
        res.status(500).send(error);
    }
});

app.get('/new', (req, res) => {
    res.render('new');
});

app.post('/posts', async (req, res) => {
    try {
        const { title, body } = req.body;
        const post = new Post({ title, body });
        await post.save();
        res.redirect('/');
    } catch (error) {
        res.status(500).send(error);
    }
});

app.get('/posts/:id', async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        res.render('show', { post });
    } catch (error) {
        res.status(500).send(error);
    }
});

app.get('/posts/:id/edit', async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        res.render('edit', { post });
    } catch (error) {
        res.status(500).send(error);
    }
});

app.post('/posts/:id', async (req, res) => {
    try {
        const { title, body } = req.body;
        await Post.findByIdAndUpdate(req.params.id, { title, body });
        res.redirect(`/posts/${req.params.id}`);
    } catch (error) {
        res.status(500).send(error);
    }
});

app.post('/posts/:id/delete', async (req, res) => {
    try {
        await Post.findByIdAndDelete(req.params.id);
        res.redirect('/');
    } catch (error) {
        res.status(500).send(error);
    }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});