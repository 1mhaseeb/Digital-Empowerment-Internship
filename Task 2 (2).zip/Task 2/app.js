const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); // Serve static files like CSS
app.set('view engine', 'ejs');

mongoose.connect('mongodb://localhost:27017/blogDB', { useNewUrlParser: true, useUnifiedTopology: true });

const postSchema = {
  title: String,
  content: String
};

const Post = mongoose.model('Post', postSchema);

// Routes

// Home Route - Read all posts
app.get('/', function(req, res) {
    Post.find({})
        .then(function(posts) {
            res.render('home', { posts: posts });
        })
        .catch(function(err) {
            console.error(err);
        });
});

// Compose Route - Show form to create new post
app.get('/compose', function(req, res) {
    res.render('compose');
});

// Post request to create a new blog post
app.post('/compose', function(req, res) {
    const post = new Post({
        title: req.body.postTitle,
        content: req.body.postContent
    });
    
    post.save()
        .then(function() {
            res.redirect('/');
        })
        .catch(function(err) {
            console.error(err);
            res.status(500).send('An error occurred while saving the post.');
        });
});

// Show individual post
app.get('/posts/:id', function(req, res) {
    const postId = req.params.id;

    Post.findById(postId)
        .then(function(post) {
            res.render('post', { title: post.title, content: post.content, id: post._id });
        })
        .catch(function(err) {
            console.error(err);
            res.status(404).send('Post not found');
        });
});

// Edit post - Show form to update post
app.get('/edit/:id', function(req, res) {
    const postId = req.params.id;

    Post.findById(postId)
        .then(function(post) {
            res.render('edit', { title: post.title, content: post.content, id: post._id });
        })
        .catch(function(err) {
            console.error(err);
            res.status(404).send('Post not found');
        });
});

// Update Post
app.post('/update/:id', function(req, res) {
    const postId = req.params.id;

    Post.findByIdAndUpdate(postId, {
        title: req.body.postTitle,
        content: req.body.postContent
    })
    .then(function() {
        res.redirect('/posts/' + postId);
    })
    .catch(function(err) {
        console.error(err);
        res.status(500).send('An error occurred while updating the post.');
    });
});

// Delete Post
app.post('/delete/:id', function(req, res) {
    const postId = req.params.id;

    Post.findByIdAndRemove(postId)
        .then(function() {
            res.redirect('/');
        })
        .catch(function(err) {
            console.error(err);
            res.status(500).send('An error occurred while deleting the post.');
        });
});

app.listen(3000, function() {
  console.log("Server started on port 3000");
});
