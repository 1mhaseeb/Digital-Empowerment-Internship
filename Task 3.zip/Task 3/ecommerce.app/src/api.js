import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api',
});

export default API;

import API from './api';

export const fetchProducts = () => async (dispatch) => {
  try {
    const { data } = await API.get('/products');
    dispatch({ type: 'FETCH_PRODUCTS_SUCCESS', payload: data });
  } catch (error) {
    dispatch({ type: 'FETCH_PRODUCTS_FAIL', payload: error.message });
  }
};

const api = axios.create({
    baseURL: 'https://your-backend-url/api',
  });
  